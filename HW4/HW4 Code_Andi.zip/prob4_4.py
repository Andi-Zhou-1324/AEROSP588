import prob4_4_a
import prob4_4_b

print("This script runs the prob4_4_a and prob4_4_b in one go")